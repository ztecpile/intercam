import { Component, OnInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { BitacoraPreciosService } from '../../services/bitacora-precios.service';
import { MatTableModule } from '@angular/material/table'
import { InstrumentoVO, MapeoDivisa, MesasOperacionVO, TipoCambioBitacoraVO } from '@intercam/model';
import { FormControl, FormGroup } from '@angular/forms';
import { ConsultaInfoGralEvent } from '../../util/ConsultaInfoGralEvent';


export class bp {
  posicion: number;
  instrumento: string;
  compra: number;
  venta: number;
  compra1: number;
  venta1: number;
  compra2: number;
  venta2: number;
  compra3: number;
  venta3: number;
  compra4: number;
  venta4: number;
}

const ELEMENT_DATA: bp[] = [
  { posicion: 1, instrumento: 'TRANSFER', compra: 0.000000, venta: 0.000000, compra1: 0.000000, venta1: 0.000000, compra2: 0.000000, venta2: 0.000000, compra3: 0.000000, venta3: 0.000000, compra4: 0.000000, venta4: 0.000000 },
  { posicion: 2, instrumento: 'EFECTIVO', compra: 0.000000, venta: 0.000000, compra1: 0.000000, venta1: 0.000000, compra2: 0.000000, venta2: 0.000000, compra3: 0.000000, venta3: 0.000000, compra4: 0.000000, venta4: 0.000000 },
];


@Component({
  selector: 'intercam-bitacora-precios',
  templateUrl: './bitacora-precios.component.html'
})
export class BitacoraPreciosComponent implements OnInit {

  displayedColumns: string[] = ['instrumento', 'compra', 'venta', 'compra2', 'venta2', 'compra3', 'venta3', 'compra4', 'venta4', 'compra5', 'venta5'];
  dataSource = new MatTableDataSource<bp>();
  // dataSource = ELEMENT_DATA;  

  perId: string; //clave de operador 
  promotor: string;
  sucursal: string;
  dataDivisas: MapeoDivisa[];
  dataCatMesas: MesasOperacionVO[];
  listInst: InstrumentoVO[];
  funcForm: FormGroup;
  cboMesaDisabled: boolean;
  dir: string = 'ini';
  campoHora: any;
  splitHora: any;
  hora: any;
  min: any;
  seg: any;
  constructor(private bPService: BitacoraPreciosService) {
    this.perId = sessionStorage.getItem('perId');
    this.promotor = sessionStorage.getItem('promotor');
    this.sucursal = sessionStorage.getItem('sucursal');
    this.cboMesaDisabled = true;
    console.log('perId: ', this.perId);

  }


  ngOnInit(): void {
    this.getPerfil(this.promotor, this.sucursal);
    this.getDivisas();
    this.getCatalogMesa();
    this.getFecha();
    this.getBitacora();
  }
  getCtr(name: string, group = ''): FormControl {
    if (group === '') return this.funcForm.get(name) as FormControl
    else return this.funcForm.controls[group].get(name) as FormControl
  }
  createFunForm() {

    // this.funcForm = this.formbuilder.group({
    this.funcForm = new FormGroup({
      cboMesa: new FormControl(''),
      cboDivisa: new FormControl(''),
      fecha: new FormControl(''),
      hora: new FormControl('')

    });
  }
  getDivisas() {
    this.bPService.getDivisas().subscribe(
      then => {
        console.log(then);
        this.dataDivisas = then;
      },
      error => {
        console.log('error', error);
      }

    )
  }

  getCatalogMesa() {
    this.bPService.getCatalogoMesas().subscribe(
      then => {
        console.log(then);
        this.dataCatMesas = then;
      },
      error => {
        console.log('error', error);
      }
    )
  }

  getPerfil(clvPro: string, clvSuc: string) {
    this.bPService.getPerfilUsuario(clvPro, clvSuc).subscribe(
      then => {
        console.log(then);
        if (then = '1') {
          this.cboMesaDisabled = false;
        }
      },
      error => {
        console.log('error', error);
      }
    )
  }

  getListInstumento() {
    this.bPService.getListInstrumentos().subscribe(
      then => {
        console.log(then);
        const listInst: InstrumentoVO[] = [];
        for (const data of then) {
          let inst = new InstrumentoVO;
          if (data.insId != 7 && data.insId != 8 && data.insId != 9) {
            inst.conSelected = data.conSelected;
            inst.insConfigura = data.insConfigura;
            inst.insDescripcion = data.insDescripcion;
            inst.insEstatus = data.insEstatus;
            inst.insId = data.insId;
            inst.insNombre = data.insNombre;
            inst.insOrden = data.insOrden;
            listInst.push(inst);
          }
        }
        this.listInst = listInst;
      },
      error => {
        console.log('error', error);
      }
    )
  }

  getFecha() {
    this.bPService.getFechaActual().subscribe(
      then => {
        console.log(then);
        const fechaActual = then.split(' ');
        this.funcForm.get('fecha').setValue(fechaActual[0]);
        this.funcForm.get('hora').setValue(fechaActual[1]);
      },
      error => {
        console.log('error', error);
      }
    )
  }

  getBitacora() {
    this.separarHora();
    const body = {
      "clvMesa": this.funcForm.get('cboMesa').value,
      "divId": this.funcForm.get('cboDivisa').value,
      "fecha": this.funcForm.get('fecha').value,
      "horas": [this.hora, this.min, this.seg],
      "dir": this.dir,
      "baseDir": "ini"
    }
    console.log(body);
    this.bPService.getBitacora(body).subscribe(
      then => {
        console.log(then);
        const dataPro: bp[] = [];
        for (const data of then) {
          let mattab = new bp;
          for (const inst of this.listInst) {
            if (data.insId == inst.insId) {
              mattab.instrumento = inst.insNombre;
            }
          }
          mattab.compra = data.tcCompra;
          mattab.compra1 = data.tcCompra;
          mattab.compra2 = data.tcCompra;
          mattab.compra3 = data.tcCompra;
          mattab.compra4 = data.tcCompra;
          mattab.venta = data.tcVenta;
          mattab.venta1 = data.tcVenta;
          mattab.venta2 = data.tcVenta;
          mattab.venta3 = data.tcVenta;
          mattab.venta4 = data.tcVenta;

          dataPro.push(mattab);
        }
        this.dataSource = new MatTableDataSource(dataPro);
      },
      error => {
        console.log('error', error);
        this.dataSource = new MatTableDataSource(ELEMENT_DATA);
      }
    )
  }

  regSig() {
    this.separarHora();
    this.dir = 'sig'
    if (this.seg == '59') {
      this.seg = '0';
      this.min += 1;
    } else {
      this.seg += 1;
    }
    if (this.min == '59') {
      this.min = '00';
      this.hora += 1;
    } else {
      this.min += 1;
    }
  }

  regAnt() {
    this.separarHora();
    this.dir = 'back'
    if (this.seg == '0') {
      this.seg = '59';
      this.min -= 1;
    } else {
      this.seg -= 1;
    }
    if (this.min == '00') {
      this.min = '59';
      this.hora -= 1;
    } else {
      this.min -= 1;
    }
  }

  separarHora() {
    this.campoHora = this.funcForm.get('hora').value;
    this.splitHora = this.campoHora.split(':');
    this.hora = this.splitHora[0];
    this.min = this.splitHora[1];
    this.seg = this.splitHora[2];
  }

}